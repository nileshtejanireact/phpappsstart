<?php

// Set variables for our request
$shop = $_GET['shop'];
$api_key = "307eaa4cc81e48927616ff26ba2998c9";
$scopes = "read_products,write_products,write_orders,read_orders,write_checkouts,read_checkouts, write_script_tags , read_script_tags ";
$redirect_uri = "https://localhost/payment_api/generate_token.php";

// Build install/approval URL to redirect to
$install_url = "https://" . $shop . "/admin/oauth/authorize?client_id=" . $api_key . "&scope=" . $scopes . "&redirect_uri=" . urlencode($redirect_uri);
print_r($install_url);
// Redirect
header("Location: " . $install_url);
die();
<?php
$dbHost     = "localhost"; 
$dbUsername = "root"; 
$dbPassword = ""; 
$dbName     = "shopify_api"; 
 
$con = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName); 
	 
	
if (!$con) { 
    die("Connection failed: " . mysqli_connect_error()); 
}


?>
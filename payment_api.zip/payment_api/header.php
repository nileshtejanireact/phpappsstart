<?php 
$shopify = $_GET;
$sql = "SELECT * FROM shops WHERE shop_url = '" . $shopify['shop'] . "' LIMIT 1";
$check = mysqli_query($con, $sql);

if(mysqli_num_rows($check) < 1){
    header("Location: install.php?shop=". $shopify['shop']);
}else{

    $shop_check = mysqli_fetch_assoc($check);
    $shop_url = $shopify['shop'];
    $access_token = $shop_check['access_token'];

    echo $shop_url .'<br>'. $access_token ;
}
?>
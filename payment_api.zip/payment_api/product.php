<div class="card" style="width: 18rem;">
<?php
$products = shopify_call($access_token, $shop_url, "/admin/api/2021-07/products.json", array(), 'GET');
$products = json_decode($products['response'], JSON_PRETTY_PRINT);

foreach($products as $product){
    foreach($product as $key => $value ){ 
        $images = shopify_call($access_token, $shop_url, "/admin/api/2021-07/products/". $value["id"]."/images.json", array(), 'GET');
        $images = json_decode($images['response'], JSON_PRETTY_PRINT);
?>
    <img src='<?php echo $images['images'][0]['src']; ?>' class="card-img-top" alt="...">
    <div class="card-body">
    <h5 class="card-title"><?php echo $value["title"]; ?></h5>
    </div>
<?php 
    }
    }
?>
</div>

